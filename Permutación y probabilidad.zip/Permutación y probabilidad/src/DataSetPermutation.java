public class DataSetPermutation {
    private String[] x2 = {"a", "b", "c"};

    public DataSetPermutation() {}

    public String[] getX2() {
        return x2;
    }

    public void setX2(String[] x2) {
        this.x2 = x2;
    }

    public String[] getDataset() {
        return x2;
    }
}