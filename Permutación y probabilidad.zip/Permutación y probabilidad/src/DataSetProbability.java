public class DataSetProbability {
    private int[][] x1 = {{7, 3}, {2, 6}};

    public DataSetProbability() {}

    public int[][] getX1() {
        return x1;
    }

    public void setX1(int[][] x1) {
        this.x1 = x1;
    }

    public int[][] getDataset() {
        return x1;
    }
}
